<?
echo getcwd();
?>