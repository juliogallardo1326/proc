<?php
/*
  Etelegate.com OSCommerse Plugin

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_ETEL_TEXT_TITLE', 'Etelegate.com');
  define('MODULE_PAYMENT_ETEL_TEXT_DESCRIPTION', 'Etelegate.com Gateway Integration');
  define('MODULE_PAYMENT_ETEL_SORT_ORDER', 'Sort Order:');
  define('MODULE_PAYMENT_ETEL_REFERENCE_ID', 'Your Website Referenc ID:');
  define('MODULE_PAYMENT_ETEL_TEST_MODE', 'Etelegate Processing Mode:');
  define('MODULE_PAYMENT_ETEL_TEXT_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_ETEL_TEXT_ERROR', 'Credit Card Error!');
?>