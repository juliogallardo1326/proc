<?
echo getcwd();
?>